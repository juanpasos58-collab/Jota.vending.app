-- ============================================================
-- Jota Family · Vending — Esquema de base de datos (Supabase)
-- Ejecuta este archivo completo en: Supabase > SQL Editor > New query
-- ============================================================

create extension if not exists pgcrypto;

-- Configuración (una sola fila)
create table if not exists raffle_config (
  id int primary key default 1,
  nombre text not null default 'Dinámica Jota Family',
  premio text not null default 'Sorpresa de la máquina de chicles',
  numero_inicio int not null default 1,
  numero_fin int not null default 60,
  valor int not null default 5000,
  whatsapp text not null default '573043750139',
  reserva_min int not null default 15,
  constraint single_row check (id = 1)
);
insert into raffle_config (id) values (1) on conflict (id) do nothing;

-- Números
create table if not exists numbers (
  numero text primary key,
  estado text not null default 'disponible'
    check (estado in ('disponible','reservado','pendiente','confirmado','cancelado')),
  nombre text,
  celular text,
  reservado_hasta timestamptz,
  request_code text
);

-- Solicitudes (participantes)
create table if not exists requests (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  nombre text not null,
  celular text not null,
  correo text,
  ciudad text not null,
  numeros text[] not null,
  estado text not null default 'pendiente',
  created_at timestamptz not null default now()
);

-- Genera/regenera los números según el rango configurado
create or replace function generar_numeros() returns void as $$
declare
  cfg raffle_config;
  digits int;
  i int;
begin
  select * into cfg from raffle_config where id = 1;
  digits := length(cfg.numero_fin::text);
  delete from numbers;
  for i in cfg.numero_inicio..cfg.numero_fin loop
    insert into numbers(numero, estado) values (lpad(i::text, digits, '0'), 'disponible');
  end loop;
end;
$$ language plpgsql security definer;

select generar_numeros();

-- Vista pública: solo número + estado (oculta nombre/celular de participantes)
create or replace view numbers_public as
select
  numero,
  case when estado = 'reservado' and reservado_hasta < now() then 'disponible' else estado end as estado
from numbers;

-- Seguridad a nivel de fila
alter table numbers enable row level security;
alter table requests enable row level security;
alter table raffle_config enable row level security;

create policy "numbers_admin_select" on numbers for select using (auth.role() = 'authenticated');
create policy "numbers_admin_update" on numbers for update using (auth.role() = 'authenticated');
create policy "requests_admin_select" on requests for select using (auth.role() = 'authenticated');
create policy "config_public_select" on raffle_config for select using (true);
create policy "config_admin_update" on raffle_config for update using (auth.role() = 'authenticated');

grant select on numbers_public to anon, authenticated;
grant select on raffle_config to anon, authenticated;
revoke execute on function generar_numeros from public;
grant execute on function generar_numeros to authenticated;

-- Reserva atómica: la usa la página pública (rol anon) vía RPC.
-- Un solo UPDATE con WHERE estado='disponible' es atómico en Postgres:
-- si dos personas intentan el mismo número al mismo tiempo, solo una lo obtiene.
create or replace function reserve_numbers(
  p_numeros text[],
  p_nombre text,
  p_celular text,
  p_correo text,
  p_ciudad text
) returns text as $$
declare
  cfg raffle_config;
  v_code text;
  v_count int;
begin
  select * into cfg from raffle_config where id = 1;

  -- auto-libera reservas vencidas antes de intentar
  update numbers set estado = 'disponible', nombre = null, celular = null,
    reservado_hasta = null, request_code = null
  where estado = 'reservado' and reservado_hasta < now();

  v_code := 'RIFA-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6));

  update numbers set
    estado = 'reservado',
    nombre = p_nombre,
    celular = p_celular,
    reservado_hasta = now() + (cfg.reserva_min::text || ' minutes')::interval,
    request_code = v_code
  where numero = any(p_numeros) and estado = 'disponible';

  get diagnostics v_count = row_count;

  if v_count <> array_length(p_numeros, 1) then
    raise exception 'NUMEROS_NO_DISPONIBLES';
  end if;

  insert into requests(code, nombre, celular, correo, ciudad, numeros)
  values (v_code, p_nombre, p_celular, p_correo, p_ciudad, p_numeros);

  return v_code;
end;
$$ language plpgsql security definer;

grant execute on function reserve_numbers to anon, authenticated;
